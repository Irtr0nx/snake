## Here we define the state class and the game state machine
