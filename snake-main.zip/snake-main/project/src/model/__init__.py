## Here we define the entities of the game (snake, fruit, board, etc)
